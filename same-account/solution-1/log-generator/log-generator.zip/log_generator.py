def lambda_handler(event, context):
    print("Hello World!")